import java.util.ArrayList;
//import java.util.Date;
import java.util.GregorianCalendar;
//import java.util.TimeZone;

/**
 * Calculates the statistics for each measurement for a given day. 
 * @author Anh-Tu Ngoc
 * @version Pre Big Bang 
 *
 */
public class DayDataStatistics
{
    /** The set of data. */
    private ArrayList<TimeData> data;

    /** Minimum tair across day. */ 
    private StatMeasurement tairMin;
    /** Maximum tair across day. */
    private StatMeasurement tairMax;
    /** Average tair across the days. */
    private StatMeasurement tairAverage;

    /** Minimum ta9m across day. */
    private StatMeasurement ta9mMin;
    /** Maximum ta9m across day. */
    private StatMeasurement ta9mMax;
    /** Average ta9m across day. */
    private StatMeasurement ta9mAverage;

    /** Minimum solar radiation across day. */
    private StatMeasurement solarRadiationMin;
    /** Maximum solar radiation across day. */
    private StatMeasurement solarRadiationMax;
    /** Average solar radiation. */
    private StatMeasurement solarRadiationAverage;

    /** Total solarRadiation */
    private StatMeasurement solarRadiationTotal;

    private String stationId = "nada";  
  
    /**
     * Constructor for the DayDatastatistics class 
     * @param inData : an arraylist containing TimeData objects 
     */
    public DayDataStatistics(ArrayList<TimeData> inData) 
    {
        // Assigning the arraylist from the parameter to the private field 
        data = inData;

       
        // These methods below calculates and assigns values to the rest of the private fields 
        calculateAirTemperatureStatistics("tair");
        calculateAirTemperatureStatistics("ta9m");  
        calculateSolarRadiationStatistics();
    }

    
    
    /**
     * Calculates air temperature 
     * @param tairName
     */
    private void calculateAirTemperatureStatistics(String tairName)
    { 
        // These variables represent the "best so far" for min and max.
        // By setting these these to the largest and smallest possible 
        // values, we ensure that the first time a valid Measurement is
        // found, it will replace these values
        double max;
        double min;
        double average; 


        
        // Accumulator and counter for computing average
        double sum = 0;
        int numberOfValidObservations = 0;

        GregorianCalendar minCalendar = new GregorianCalendar();
        GregorianCalendar maxCalendar = new GregorianCalendar();
        
        // FINISH IMPLEMENTATION

        
        if ( tairName.equalsIgnoreCase("tair"))
        {
            min = data.get(0).getTair().getValue(); 
            max = data.get(0).getTair().getValue();  
            
            // Iterating through arrayList of Time Data 
            for (int index = 0; index < data.size(); ++index)  
            {
                
                if (data.get(index).getTair().isValid())
                {
                    sum = sum + data.get(index).getTair().getValue();
                    numberOfValidObservations = numberOfValidObservations + 1; 
                }
                
                // Computing tairMax
                if ( data.get(index).getTair().isValid() && data.get(index).getTair().getValue() > max )
                {
                    max = data.get(index).getTair().getValue();
                    maxCalendar = data.get(index).getMeasurementDateTime(); 
                    stationId = data.get(index).getStationID();
                }
                
                // Computing tairMin 
                if ( data.get(index).getTair().isValid() &&
                        data.get(index).getTair().getValue() < min ) 
                {
                    min = data.get(index).getTair().getValue();  
                    minCalendar = data.get(index).getMeasurementDateTime(); 
                    stationId = data.get(index).getStationID(); 
                }
     
            } 
            
            tairMax = new StatMeasurement( max, maxCalendar, stationId, "TAIR", StatType.MAX);
            tairMin = new StatMeasurement( min, minCalendar, stationId, "TAIR", StatType.MIN);
            average = sum / numberOfValidObservations;   
            
            // RETURN AND CHECK: obsDateTime and StationID
            tairAverage = new StatMeasurement(average, new GregorianCalendar(), stationId, "TAIR", StatType.AVG);
            
        }
        
        if ( tairName.equalsIgnoreCase("ta9m"))
        {
            min = data.get(0).getTa9m().getValue(); 
            max = data.get(0).getTa9m().getValue(); 
 
            
            // Iterating through arrayList of Time Data 
            for (int index = 0; index < data.size(); ++index)
            {
                
                if (data.get(index).getTa9m().isValid())
                {
                    sum = sum + data.get(index).getTa9m().getValue();
                    numberOfValidObservations = numberOfValidObservations + 1; 
                }
                
                // Computing ta9mMax
                if ( data.get(index).getTa9m().isValid() && 
                        data.get(index).getTa9m().getValue() > max )
                {
                    max = data.get(index).getTa9m().getValue();
                    maxCalendar = data.get(index).getMeasurementDateTime(); 
                    stationId = data.get(index).getStationID();
                }
                
                // Computing ta9mMin 
                if ( data.get(index).getTa9m().isValid() &&
                        data.get(index).getTa9m().getValue() < min ) 
                {
                    min = data.get(index).getTa9m().getValue(); 
                    minCalendar = data.get(index).getMeasurementDateTime(); 
                    stationId = data.get(index).getStationID(); 
                }
     
            }
            
            ta9mMax = new StatMeasurement( max, maxCalendar, stationId, "TA9M", StatType.MAX);
            ta9mMin = new StatMeasurement( min, minCalendar, stationId, "TA9M", StatType.MIN);
            average = sum / numberOfValidObservations;   
            
            // RETURN AND CHECK: obsDateTime and StationID
            ta9mAverage = new StatMeasurement(average, new GregorianCalendar(), stationId, "TA9M", StatType.AVG);
            
        }
        
        // RETURN AND CHECK: See if there needs to be an exception thrown 
        
    }

    /**
     * Compute and fill in the solar radiation-related statistics
     * (solarRadiationMin, solarRadiationMax, solarRadiationAverage, and
     * solarRadiationTotal).
     * <P>
     * Notes:
     * <UL>
     * <LI>Only valid Measurements can be used in these computations
     * <LI>You may assume that every month has at least one valid Measurement
     * </UL>
     */
    private void calculateSolarRadiationStatistics()
    {
        // These variables represent the "best so far" for min and max.
        // By setting these these to the largest and smallest possible
        // values, we ensure that the first time a valid Measurement is
        // found, it will replace these values
        double max = data.get(0).getSolarRadiation().getValue(); 
        double min = data.get(0).getSolarRadiation().getValue();
        double average; 

        // Accumulator and counter for computing average
        double sum = 0;
        int numberOfValidObservations = 0;

        GregorianCalendar minCalendar = new GregorianCalendar();
        GregorianCalendar maxCalendar = new GregorianCalendar();
        
        // FINISH IMPLEMENTATION
        
        
        for (int index = 0; index < data.size(); ++index)
        { 
            
            if (data.get(index).getSolarRadiation().isValid())
            {
                sum = sum + data.get(index).getSolarRadiation().getValue();
                numberOfValidObservations = numberOfValidObservations + 1; 
            }

            // Computing maximum radiation for that day
            // Compute it only if the solarRadiation value is valid
            if ((data.get(index).getSolarRadiation().getValue() > max)
                    && (data.get(index).getSolarRadiation().isValid()))
            {
                max = data.get(index).getSolarRadiation().getValue();
                maxCalendar = data.get(index).getMeasurementDateTime(); 
                stationId = data.get(index).getStationID(); 
            }
            // Computing minimum radiation for that day
            // Compute it only if the solarRadiation value is valid
            if (data.get(index).getSolarRadiation().getValue() < min
                    && (data.get(index).getSolarRadiation().isValid())) 
            {
                min = data.get(index).getSolarRadiation().getValue();
                minCalendar = data.get(index).getMeasurementDateTime(); 
                stationId = data.get(index).getStationID(); 
            }        
        }
        
        average = sum / numberOfValidObservations; 
        
        solarRadiationMax = new StatMeasurement( max, maxCalendar, stationId, "SRAD", StatType.MAX );
        solarRadiationMin = new StatMeasurement( min, minCalendar, stationId, "SRAD", StatType.MIN );
        solarRadiationTotal = new StatMeasurement( sum, new GregorianCalendar(), stationId, "SRAD", StatType.TOT); 
        solarRadiationAverage = new StatMeasurement( average, new GregorianCalendar(), 
                                stationId, "SRAD", StatType.AVG); 


    }
    

    /**
     * @return solarRadiationAverage : average of solar radiation
     */
    public StatMeasurement getSolarRadiationAverage()
    {
        return solarRadiationAverage; 
    }

    /** 
     * @return solarRadiationMax : maximum value of solar radiation
     */
    public StatMeasurement getSolarRadiationMax()
    {
        return solarRadiationMax; 
    }

    /**
     * @return solarRadiationMin : minimum value of solar radiation
     */
    public StatMeasurement getSolarRadiationMin()
    {
        return solarRadiationMin; 
    }

    /**
     * @return solarRadiationTotal : total value of solar radiation
     */
    public StatMeasurement getSolarRadiationTotal()
    {
        return solarRadiationTotal;  
    }

    /**
     * @return stationId : the id of the station 
     */
    public String getStationID()
    {
        return stationId; 
    }

    /**
     * @return ta9mAverage : average value of air temperature at 9m
     */
    public StatMeasurement getTa9mAverage()
    {
        return ta9mAverage; 
    }

    /**
     * @return ta9mMax : maximum value of air temperature at 9m
     */
    public StatMeasurement getTa9mMax()
    {
        return ta9mMax; 
    }

    /**
     * @return ta9mMin : minimum value of air temperature at 9m
     */
    public StatMeasurement getTa9mMin()
    {
        return ta9mMin; 
    }

    /**
     * @return tairAverage : average value of air temperature at 9m
     */
    public StatMeasurement getTairAverage()
    {
        return tairAverage; 
    }

    /**
     * @return tairMax : maximum value of air temperature
     */
    public StatMeasurement getTairMax()
    {
        return tairMax; 
    }

    /**
     * @return tairMin : minimum value of air temperature
     */
    public StatMeasurement getTairMin()
    {
        return tairMin;
    }



    /**
     * Describe DayStatistics
     * 
     * @return A string describing the statistics for the day
     */
    public String toString() 
    {
        String tairString = tairMin.getValue() + "\t" + tairMax.getValue() 
                            + "\t" + tairAverage.getValue() + "\n"; 
        String ta9mString = ta9mMin.getValue() + "\t" + ta9mMax.getValue() 
                            + "\t" + ta9mAverage.getValue() + "\n"; 
        String solarString = solarRadiationMin.getValue() + "\t" + solarRadiationMax.getValue() 
                            + "\t" + solarRadiationAverage.getValue() + "\t" + solarRadiationTotal.getValue() + "\n"; 
        String header = "Min" + "\t" + "Max" + "\t" + "Average" + "\t" + "Total" + "\n"; 
        
        String output = header + tairString + ta9mString + solarString;  
        return output; 

    }
}
