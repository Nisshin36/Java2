import org.junit.Test;

import java.io.IOException;
import java.text.ParseException;

import org.junit.Assert; 

/**
 * Class testing the DaysStatistics class 
 * @author Anh-Tu Ngoc
 * @version July 4th 1776 
 */
public class DaysStatisticsTest 
{

    /**
     * Testing the find statistics class 
     * @throws WrongParameterIdException
     * @throws IOException
     * @throws WrongCopyrightException
     * @throws ParseException
     */
    @Test
    public void findStatisticsTest() throws WrongParameterIdException, IOException, 
                                     WrongCopyrightException, ParseException 
    {
        String[] files = {"data/testfile.txt", "data/testfile.txt"};         
        DaysStatistics ds = new DaysStatistics(files); 
        ds.findStatistics();  
        
        String expected = "TAIR" + "\t" + "MIN" + "\t" + "STIL" + "\t" + "-9.0";
        Assert.assertEquals( expected , ds.getMinimumDay("tair"));  
         
         
        
    }
    
    
    
     
}
